<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Response;
use App\Models\sales;
use App\Models\sales_paid;
use App\Models\sales_detail;
use App\Models\customer_students;
use App\Models\sales_month_paid;
use App\Http\Controllers\OpenpayController;

class salesController extends Controller
{
    public function cancelSales(Request $req)
    {
        $sales = Sales::find($req->id);
        $sales->topic = $req->topic;
        $sales->cancelled = 1;

        $sales->save();

    }

    public function addOrderwhitoutPay( Request $req)
    {
        try{
            for ($h=0; $h < count($req->planes); $h++) {
                $plan = $req->planes[$h];


                $sales = new sales();

                $alumno = $plan['alumnos'];

                $code_paid =  $alumno['code'];
                $months = $plan['months'];

                $sales->folio = $this->getFolio();
                $sales->id_customer = $req->user_id;
                $sales->id_plan = $plan['id'];
                $sales->discount = 0;
                $sales->id_student = $alumno['id'];
                $sales->payeds_in_months = $months;
                $sales->payed_mounth = $plan['price'];
                $sales->payed = 0;
                $sales->code = $code_paid;
                $sales->total_debt = $plan['price'] * $months;
                if($sales->save())
                {

                    $mount = $plan['price'];
                    $month_number = date('m');
                    $date =  date("Y-m-d");

                    for ($i=0; $i < $months; $i++) {
                        $sales_month_paid = new sales_month_paid();

                        $sales_month_paid->date = date("Y-m-d", strtotime("+$i month",strtotime($date)));
                        $sales_month_paid->mount = $mount;
                        $sales_month_paid->id_sales  = $sales->id;

                        $sales_month_paid->save();

                    }

                    $sales_detail = new sales_detail();

                    $sales_detail->id_sales = $sales->id;
                    $sales_detail->data = json_encode($plan['plane_data'], true);
                    $sales_detail->save();

                    //añadir pago

                    $sales = sales::find($sales->id);

                    $description = "PAGO REALIZADO DESDE OPENPAY  ID: ".$req->id_cargo ;
                    $sales_paid = new  sales_paid();

                    $sales_paid->ref = $req->id_cargo;
                    $sales_paid->paid_date =  date("Y-m-d");
                    $sales_paid->ref_long = $description;
                    $sales_paid->paid =  $plan['price'];
                    $sales_paid->mount =  $plan['price'];
                    $sales_paid->status = 1;
                    $sales_paid->id_sales = $sales->id;

                    if($sales_paid->save()){

                        $sales->payed = $sales->payed +  $plan['price'];
                        $sales->total_debt = $sales->total_debt -  $plan['price'];
                        $sales->save();
                    }




            }
            }

    		return Response::json(array('status' => '200', 'data' => "ok"));
		}catch(Exeption $e)
		{
			return Response::json(array('status' => '500', 'data' => ''));
		}
    }

    public function add(Request $req)
    {

        $openpay_ctr = new OpenpayController();
        $result = $openpay_ctr->addCharger(

            $req->credit_card,
            $req->device_session_id,
            $req->plan['description'],
            $req->plan['price']

        );

        if($result == 0)
        {
            return Response::json(array('status' => '500', 'data' => ''));
        }
        // $req->all()

        try{
            for ($i=0; $i < count($req->alumnos); $i++) {
                $sales = new sales();

                $code_paid =  $req->alumnos[$i]['code'];
                $months = $req->plan['months'];

                $sales->folio = $this->getFolio();
                $sales->id_customer = $req->user_id;
                $sales->id_plan = $req->plan['id'];
                $sales->discount = 0;
                $sales->id_student = $req->alumnos[$i]['id'];
                $sales->payeds_in_months = $months;
                $sales->payed_mounth = $req->plan['price'];
                $sales->payed = 0;
                $sales->code = $code_paid;
                $sales->total_debt = $req->plan['price'] * $months;
                if($sales->save())
                {

                    $months = $req->plan['months'];
                    $mount = $req->plan['price'];
                    $month_number = date('m');
                    $date =  date("Y-m-d");

                    for ($i=0; $i < $months; $i++) {
                        $sales_month_paid = new sales_month_paid();

                        $sales_month_paid->date = date("Y-m-d", strtotime("+$i month",strtotime($date)));
                        $sales_month_paid->mount = $mount;
                        $sales_month_paid->id_sales  = $sales->id;

                        $sales_month_paid->save();

                    }

                    $sales_detail = new sales_detail();

                    $sales_detail->id_sales = $sales->id;
                    $sales_detail->data = json_encode($req->plan, true);
                    $sales_detail->save();

                    ///añadir pago

                    $sales = sales::find($sales->id);

                    $description = "PAGO REALIZADO DESDE OPENPAY  ID: ".$result['id_cargo'] ;
                    $sales_paid = new  sales_paid();

                    $sales_paid->ref = $result['id_cargo'];
                    $sales_paid->paid_date =  date("Y-m-d");
                    $sales_paid->ref_long = $description;
                    $sales_paid->paid =  $req->plan['price'];
                    $sales_paid->mount =  $req->plan['price'];
                    $sales_paid->status = 1;
                    $sales_paid->id_sales = $sales->id;

                    if($sales_paid->save()){

                        $sales->payed = $sales->payed +  $req->plan['price'];
                        $sales->total_debt = $sales->total_debt -  $req->plan['price'];
                        $sales->save();
                    }

                }


            }

    		return Response::json(array('status' => '200', 'data' => "ok"));
		}catch(Exeption $e)
		{
			return Response::json(array('status' => '500', 'data' => ''));
		}
    }


    public function payInvoice(Request $req){
        try{
            $openpay_ctr = new OpenpayController();
            $result = $openpay_ctr->addCharger(

                $req->id_card,
                $req->id_device,
                "PAGO REALIZADO DESDE OPENPAY $".$req->price,
                $req->price

            );

            if($result == 0)
            {
                return Response::json(array('status' => '500', 'data' => ''));
            }


            $sales = sales::find($req->id_sales);

            $description = "PAGO REALIZADO DESDE OPENPAY  ID: ".$result['id_cargo'] ;
            $sales_paid = new  sales_paid();

            $sales_paid->ref = $result['id_cargo'];
            $sales_paid->paid_date =  date("Y-m-d");
            $sales_paid->ref_long = $description;
            $sales_paid->paid =  $req->price;
            $sales_paid->mount =  $req->price;
            $sales_paid->status = 1;
            $sales_paid->id_sales = $sales->id;

            if($sales_paid->save()){

                $sales->payed = $sales->payed + $req->price;
                $sales->total_debt = $sales->total_debt -  $req->price;
                $sales->save();
            }

        return Response::json(array('status' => '200', 'data' => "ok"));
        }catch(Exeption $e)
        {
            return Response::json(array('status' => '500', 'data' => ''));
        }

    }

    public function getFolio()
    {
        $start  = 0;
        $count  = 1;
        $digits = 10;
        $result = array();
        for ($n = $start; $n < $start + $count; $n++) {
         $result = str_pad($n, $digits, "0", STR_PAD_LEFT);
         $folio  = sales::where('folio','=', $result)->first();
         if ($folio) {
          $count = $count + 1;
         }
        }
        return $result;
    }


    public function show()
    {
        try{
            $sales = sales::with('details')->with('paids')->with('mounth_paids')->with('student')->orderBy('folio', 'asc')->where('cancelled', '=', 0)->get();
    		return Response::json(array('status' => '200', 'data' => $sales));
		}catch(Exeption $e)
		{
			return Response::json(array('status' => '500', 'data' => ''));
		}

    }

    public function showByCustomer(Request $req)
    {
        try{
            $sales = sales::with('details')->with('paids')->with('mounth_paids')->with('student')->orderBy('folio', 'asc')->where('id_customer','=',$req->id_user)->get();
    		return Response::json(array('status' => '200', 'data' => $sales));
		}catch(Exeption $e)
		{
			return Response::json(array('status' => '500', 'data' => ''));
		}

    }

    public function addDV(Request $req)
    {
        try{
            $codes = $req->codes;
            for ($i=0; $i < count($codes); $i++) {
                if($codes[$i] !== "")
                {
                    $codes[$i] = explode("\t",$codes[$i])[0];

                    $code = substr($codes[$i], 0, -1);
                    $dv = substr($codes[$i], -1);

                    $sales_paid =  sales_paid::where('codigo_paid', '=', $code)->first();

                    $sales_paid->digit_verification = $dv;

                    $sales_paid->save();
                }
            }


    		return Response::json(array('status' => '200', 'data' => $sales_paid));
		}catch(Exeption $e)
		{
			return Response::json(array('status' => '500', 'data' => ''));
		}
    }

    public function addPaidManual(Request $req)
    {
        try{
            $sales = sales::find($req->sales_id);
            // return $sales;
            $description = $req->description;
            $sales_paid = new  sales_paid();

            $sales_paid->ref = $req->ref;
            $sales_paid->paid_date = $req->date;
            $sales_paid->ref_long = $description;
            $sales_paid->paid =  $req->mount;
            $sales_paid->mount =  $sales->payed_mounth;
            $sales_paid->status = 1;
            $sales_paid->id_sales = $req->sales_id;

            if($sales_paid->save()){

                $sales->payed = $sales->payed +  $req->mount;
                $sales->total_debt = $sales->total_debt -  $req->mount;
                $sales->save();
            }


            return Response::json(array('status' => '200', 'data' => $sales_paid));
        }catch(Exception $e)
        {
            return Response::json(array('status' => '500', 'data' => ''));
        }
    }

    public function addPaid(Request $req)
    {
        try{
            $data = $req->data;
            for ($i=0; $i <  count($data); $i++) {

                $customer_students = customer_students::where(DB::raw("CONCAT(code,dv)"),'=', $data[$i]['Concepto'] )->first();


                if($customer_students != null)
                {
                    $sales = sales::where('id_student', '=', $customer_students->id)->where('end_sale','=', 0)->first();


                    $validacion = sales_paid::where('paid_date', '=', $data[$i]['Día'])
                    ->where('ref_long', '=', $data[$i]['Concepto / Referencia'])
                    ->where('paid','=',$data[$i]['Abono'] )
                    ->get();

                    if(count($validacion) == 0){
                        $sales_paid = new  sales_paid();



                        $sales_paid->ref = $data[$i]['Concepto'];
                        $sales_paid->paid_date = $data[$i]['Día'];
                        $sales_paid->ref_long = $data[$i]['Concepto / Referencia'];
                        $sales_paid->paid =  $data[$i]['Abono'];
                        $sales_paid->mount =  $sales->payed_mounth;
                        $sales_paid->status = 1;
                        $sales_paid->id_sales = $sales->id;

                        if($sales_paid->save())
                        {
                            $date_month = $data[$i]['month'];
                            $month_paid = sales_month_paid::where('id_sales','=', $sales->id)->whereRaw("date_format(date, '%Y-%m') = '$date_month'")->first();

                            if(!empty($moth_paid)){

                                $month_paid->id_paid_sales = $sales_paid->id;

                                $month_paid->save();

                                $sales->payed = $sales->payed + $data[$i]['Abono'];
                                $sales->total_debt = $sales->total_debt - $data[$i]['Abono'];
                                $sales->save();
                            }
                        }
                    }
                }
            }

            $this->refreshPaid();

            return Response::json(array('status' => '200', 'data' => 'ok'));
        }catch(Exception $e)
        {
            return Response::json(array('status' => '500', 'data' => ''));
        }
    }

    public function refreshPaid(){
        $sales = sales::where('total_debt', '<>', 0)->get();

        for ($i=0; $i < count($sales); $i++) {
            $months = $sales[$i]->payeds_in_months;
            $payed_mounth = $sales[$i]->payed_mounth;
            $total = $payed_mounth * $months;
            $sales_paid = sales_paid::where('id_sales', '=', $sales[$i]->id)->get();

            $total_paid = 0;

            for ($j=0; $j < count($sales_paid); $j++) {
                $total_paid += $sales_paid[$j]->paid;
            }

            $sales[$i]->payed = $total_paid;
            $sales[$i]->total_debt = $total - $total_paid;


            $sales[$i]->save();


        }

    }

    public function active_account(Request $req){
        try{
            $sales = sales::find($req->id);

            $sales->status = $req->status;

            $sales->save();
            return Response::json(array('status' => '200', 'data' => $sales));
        }catch(Exception $e)
        {
            return Response::json(array('status' => '500', 'data' => ''));
        }
    }

    public function addInfo(Request $req)
    {

    }
}
